function out = parseSimulinkData(sim_out, int_idx, fnl_idx, n_dof, idx_mode)
% ----------------------------------------------------------------------
% Parse Simulink simulation output data for dynamic identification.
% Expected data in sim_out (SimulationOutput object):
%   tout  : 1D array, simulation time
%   pos   : position trajectory (n_samples x n_dof)
%   vel   : velocity trajectory
%   tor   : torque trajectory
%
% idx_mode (optional):
%   'index' (default) - int_idx/fnl_idx are sample row indices (1-based)
%   'time'            - int_idx/fnl_idx are time in seconds [t_start, t_end]
%
% Output struct:
%   t     : time (shifted to start at 0)
%   q     : joint position
%   qd    : joint velocity
%   tau   : joint torque
%   n_dof : number of degrees of freedom
% ----------------------------------------------------------------------

if nargin < 5 || isempty(idx_mode)
    idx_mode = 'index';
end

tout = sim_out.tout(:);
pos  = sim_out.pos;
vel  = sim_out.vel;
tor  = sim_out.tor;

if nargin < 4 || isempty(n_dof)
    n_dof = size(pos, 2);
    if n_dof < 1
        error('parseSimulinkData: cannot infer n_dof from pos data. Pass n_dof explicitly.');
    end
end

switch lower(idx_mode)
    case 'time'
        t_start = int_idx;
        t_end = fnl_idx;
        i0 = find(tout >= t_start, 1, 'first');
        i1 = find(tout <= t_end, 1, 'last');
        if isempty(i0) || isempty(i1) || i0 > i1
            error('parseSimulinkData: time window [%.3f, %.3f] s is outside tout [%.3f, %.3f] s.', ...
                t_start, t_end, tout(1), tout(end));
        end
        int_idx = i0;
        fnl_idx = i1;
    case 'index'
        int_idx = round(int_idx);
        fnl_idx = round(fnl_idx);
    otherwise
        error('parseSimulinkData: idx_mode must be ''index'' or ''time''.');
end

if fnl_idx > length(tout) || int_idx < 1 || int_idx > fnl_idx
    error('parseSimulinkData: int_idx/fnl_idx out of bounds (tout has %d samples).', length(tout));
end

out = struct;
out.n_dof = n_dof;
out.t   = tout(int_idx:fnl_idx) - tout(int_idx);
out.q   = pos(int_idx:fnl_idx, 1:n_dof);
out.qd  = vel(int_idx:fnl_idx, 1:n_dof);
out.tau = tor(int_idx:fnl_idx, 1:n_dof);

fprintf('parseSimulinkData: %d samples, t=[0, %.2f] s (abs [%.2f, %.2f] s), mode=%s\n', ...
    numel(out.t), out.t(end), tout(int_idx), tout(fnl_idx), idx_mode);

end