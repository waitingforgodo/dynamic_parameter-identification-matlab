function out = parseSimulinkData(sim_out, int_idx, fnl_idx, n_dof, idx_mode, units)
% ----------------------------------------------------------------------
% Parse robot measurement data (CSV or Simulink SimulationOutput).
%
% CSV layout (Marvin 真机, 1 kHz):
%   col1: time(s), col2-8: q(deg), col9-15: qd(deg/s), col16-22: tau(Nm)
%
% idx_mode: 'index' | 'time'
% units: 'deg' (default, 真机 CSV) | 'rad' (Simulink 弧度制)
% ----------------------------------------------------------------------

if nargin < 5 || isempty(idx_mode)
    idx_mode = 'index';
end
if nargin < 6 || isempty(units)
    units = 'deg';
end

% 区分仿真与真机
if isstruct(sim_out) && isfield(sim_out, 'tout')
    tout = sim_out.tout(:);
    pos  = sim_out.pos;
    vel  = sim_out.vel;
    tor  = sim_out.tor;
    units = 'rad';
else
    traj = readmatrix(sim_out);
    tout = traj(2:end, 1);
    pos  = traj(2:end, 2:8);
    vel  = traj(2:end, 9:15);
    tor  = traj(2:end, 16:22);
end

if nargin < 4 || isempty(n_dof)
    n_dof = size(pos, 2);
    if n_dof < 1
        error('parseSimulinkData: cannot infer n_dof from pos data.');
    end
end
% 分类型解析参数
switch lower(idx_mode)
    case 'time'
        t_start = int_idx;
        t_end = fnl_idx;
        i0 = find(tout >= t_start, 1, 'first');
        i1 = find(tout <= t_end, 1, 'last');
        if isempty(i0) || isempty(i1) || i0 > i1
            error('parseSimulinkData: time window [%.3f, %.3f] s outside data [%.3f, %.3f] s.', ...
                t_start, t_end, tout(1), tout(end));
        end
        int_idx = i0;
        fnl_idx = i1;
    case 'index'
        int_idx = round(int_idx);
        fnl_idx = round(fnl_idx);
    otherwise
        error('parseSimulinkData: idx_mode must be ''index'' or ''time''.');
end

if fnl_idx > length(tout) || int_idx < 1 || int_idx > fnl_idx
    error('parseSimulinkData: indices out of bounds (length=%d).', length(tout));
end

out = struct;
out.n_dof = n_dof;
out.t   = tout(int_idx:fnl_idx) - tout(int_idx);
out.q   = pos(int_idx:fnl_idx, 1:n_dof);
out.qd  = vel(int_idx:fnl_idx, 1:n_dof);
out.tau = tor(int_idx:fnl_idx, 1:n_dof);
% 重要：回归矩阵要求rad,需转换
if strcmpi(units, 'deg')
    out.q  = deg2rad(out.q);
    out.qd = deg2rad(out.qd);
end

fprintf('parseSimulinkData: %d samples, t=[0, %.2f] s, units=%s\n', ...
    numel(out.t), out.t(end), units);

end
