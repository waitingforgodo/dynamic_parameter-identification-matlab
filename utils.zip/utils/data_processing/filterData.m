function data = filterData(data)
% ---------------------------------------------------------------------
% 动力学辨识用滤波：保证 q / qd / q2d 来自同一条运动学链（弧度制）
%
% 核心思想：
%   不直接使用原始传感器速度/加速度（噪声大、不一致）
%   统一从【滤波后的位置】出发，逐级微分得到速度、加速度
%   保证三者运动学一致，适合最小二乘辨识动力学参数
%
% 流程：
%   1) 位置 q 轻滤波（SG + 低通）
%   2) 由 q 中心差分得 qd（保证运动学一致）
%   3) 由 qd 中心差分 + 低通得 q2d
%   4) 力矩 tau 低通滤波
%   5) 去除首尾 10% 过渡段（避免边界微分突变）
%
% 输入/输出字段：
%   data.t        时间 (s)
%   data.q        原始关节位置 (rad)
%   data.qd       原始关节速度 (rad/s)
%   data.tau      原始关节力矩 (N·m)
% 输出新增：
%   data.q        滤波后位置（辨识用）
%   data.qd_fltrd 滤波后速度（辨识用）
%   data.q2d_est  滤波后加速度（辨识用）
%   data.tau_fltrd滤波后力矩（辨识用）
%   data.acc_raw  原始速度差分加速度（仅绘图对比）
% ---------------------------------------------------------------------

% 把数据展成列向量，避免维度错误
t = data.t(:);
q = data.q;            % 原始位置（rad）
qd_raw = data.qd;      % 原始速度（仅用于对比，不进辨识）
tau = data.tau;        % 原始力矩（N·m）

n_dof = size(q, 2);    % 机器人关节数量
data.n_dof = n_dof;    % 存入结构体，方便绘图使用

%% ===================== 1. 计算采样频率与滤波参数 =====================
dt = median(diff(t));          % 稳定计算平均采样间隔（避免个别跳变）
fs = 1 / dt;                   % 采样频率 Hz

% 截止频率设置（根据轨迹频率自适应，同时不超过 Nyquist 频率）
% 激励轨迹基频约 1/T；T=120,N=5 时最高谐波 ~0.04 Hz，留 5 Hz 低通足够且少失真
fc_pos = min(5, 0.4 * fs);     % 位置低通截止频率
fc_acc = min(3, 0.3 * fs);     % 加速度低通截止频率
fc_tau = min(5, 0.4 * fs);     % 力矩低通截止频率

% 归一化截止频率（butter 函数要求）
Wn_pos = fc_pos / (fs / 2);
Wn_acc = fc_acc / (fs / 2);
Wn_tau = fc_tau / (fs / 2);

% 4阶巴特沃斯低通滤波器（保证足够平滑，无相位偏移）
[b_pos, a_pos] = butter(4, max(Wn_pos, 0.01), 'low');
[b_acc, a_acc] = butter(4, max(Wn_acc, 0.01), 'low');
[b_tau, a_tau] = butter(4, max(Wn_tau, 0.01), 'low');

%% ===================== 2. 位置滤波（核心：先平滑位置再求导） =====================
qf = q;
for i = 1:n_dof
    % SG 滤波：多项式平滑，适合后续求导，不扭曲波形
    if length(qf(:, i)) > 15
        qf(:, i) = sgolayfilt(qf(:, i), 3, 15);
    end
    % 零相位低通滤波（无滞后，不产生相位失真）
    qf(:, i) = filtfilt(b_pos, a_pos, qf(:, i));
end

%% ===================== 3. 从平滑位置求速度（保证运动学一致） =====================
% 速度 = 滤波位置的中心差分（不再使用原始速度作为辨识输入）
qdf = central_diff(qf, t);

%% ===================== 4. 从平滑速度求加速度 =====================
% 加速度 = 平滑速度的中心差分
q2df = central_diff(qdf, t);

% 加速度噪声极大，必须再低通滤波
for i = 1:n_dof
    q2df(:, i) = filtfilt(b_acc, a_acc, q2df(:, i));
end

%% ===================== 5. 力矩滤波 =====================
tauf = tau;
for i = 1:n_dof
    tauf(:, i) = filtfilt(b_tau, a_tau, tau(:, i));
end

%% ===================== 6. 计算原始速度差分加速度（仅用于对比绘图） =====================
acc_raw = central_diff(qd_raw, t);

%% ===================== 7. 去除首尾过渡段（解决边界突变） =====================
N = length(t);
rm = max(round(0.05 * N), 1);        % 去掉前后 5% 数据
idx = (rm + 1):(N - rm);            % 有效数据索引

% 把有效段赋值回 data 结构体
data.t         = t(idx);
data.q         = qf(idx, :);        % 辨识用：滤波位置（rad）
data.qd        = qd_raw(idx, :);    % 原始速度，仅供对比
data.qd_fltrd  = qdf(idx, :);       % 辨识用：与 q 一致的速度（rad/s）
data.q2d_est   = q2df(idx, :);      % 辨识用：与 q 一致的加速度（rad/s^2）
data.tau       = tau(idx, :);
data.tau_fltrd = tauf(idx, :);
data.acc_raw   = acc_raw(idx, :);

%% ===================== 8. 绘图对比 =====================
plotAll(data);

end

%% ===================== 中心差分函数（稳定、无漂移） =====================
function d = central_diff(y, t)
% 功能：对 y 进行时间 t 的中心差分
% 输入：
%   y  位置/速度 矩阵 (n_samples × n_dof)
%   t  时间向量 (n_samples × 1)
% 输出：
%   d  一阶导数（速度/加速度）
% 特点：
%   只对中间点差分；首尾直接复制邻点，避免边界爆冲

n = size(y, 1);
d = zeros(size(y));

% 中心差分（只计算 2 ~ end-1，最稳定）
for i = 2:n - 1
    dt_i = t(i + 1) - t(i - 1);
    if dt_i > 0
        d(i, :) = (y(i + 1, :) - y(i - 1, :)) / dt_i;
    end
end

% 边界处理：首尾点 = 相邻点，避免突变
d(1, :) = d(2, :);
d(n, :) = d(n - 1, :);
end

%% ===================== 绘图函数：位置、速度、加速度、力矩对比 =====================
function plotAll(trj)
n = trj.n_dof;

% 图1：滤波后位置（辨识用，已转角度）
figure('Name', '位置（滤波后，辨识用）');
for i = 1:n
    subplot(3, 3, i);
    plot(trj.t, rad2deg(trj.q(:, i)), 'b', 'LineWidth', 1.2);
    grid on; title(sprintf('关节%d q', i));
    xlabel('t (s)'); ylabel('deg');
end

% 图2：原始速度 vs 辨识用速度
figure('Name', '速度对比');
for i = 1:n
    subplot(3, 3, i);
    plot(trj.t, rad2deg(trj.qd(:, i)), 'r', 'DisplayName', '原始'); hold on;
    plot(trj.t, rad2deg(trj.qd_fltrd(:, i)), 'b', 'LineWidth', 1.2, 'DisplayName', '辨识用');
    grid on; legend; title(sprintf('关节%d', i));
end

% 图3：原始加速度 vs 辨识用加速度
figure('Name', '加速度对比');
for i = 1:n
    subplot(3, 3, i);
    plot(trj.t, rad2deg(trj.acc_raw(:, i)), 'r', 'DisplayName', '原始差分'); hold on;
    plot(trj.t, rad2deg(trj.q2d_est(:, i)), 'b', 'LineWidth', 1.2, 'DisplayName', '辨识用');
    grid on; legend; title(sprintf('关节%d', i));
end

% 图4：原始力矩 vs 滤波力矩
figure('Name', '力矩对比');
for i = 1:n
    subplot(3, 3, i);
    plot(trj.t, trj.tau(:, i), 'r', 'DisplayName', '原始'); hold on;
    plot(trj.t, trj.tau_fltrd(:, i), 'b', 'LineWidth', 1.2, 'DisplayName', '滤波');
    grid on; legend; title(sprintf('关节%d', i));
end
end