function filtered_data= show_filter(path_to_est_data,idx,idx_mode)
tempData  = parseSimulinkData(path_to_est_data, idx(1), idx(2), [], idx_mode);
n_dof = tempData.n_dof;
idntfcnTrjctry = parseSimulinkData(path_to_est_data, idx(1), idx(2), n_dof, idx_mode);
filtered_data = filterData(idntfcnTrjctry);